document.addEventListener("DOMContentLoaded", async function () {
    const baseUrl = 'http://localhost:8080';

    async function listarProdutos() {
        try {
            const response = await fetch(`${baseUrl}/produtos`);
            if (!response.ok) {
                throw new Error(`Erro na solicitação: ${response.status}`);
            }
            const data = await response.json();

            console.log(data);

            const produtoList = document.getElementById('produto-list');
            produtoList.innerHTML = '';
            data.forEach(produto => {
                const listItem = document.createElement('li');
                listItem.textContent = `Código: ${produto.codigoProduto}, Descrição: ${produto.descricao}, Unidade de Medida: ${produto.unidadeDeMedida}, Vencimento: ${produto.vencimento}`;
                produtoList.appendChild(listItem);
            });
        } catch (error) {
            console.error(error);
        }
    }

    listarProdutos();

    // Função para buscar um produto por código
    function buscarProdutoPorCodigo(codigo) {
        fetch(`${baseUrl}/produtos/${codigo}`)
            .then(response => {
                if (response.status === 200) {
                    return response.json();
                } else {
                    return null;
                }
            })
            .then(produto => {
                const produtoDetalhes = document.getElementById('produto-detalhes');
                produtoDetalhes.innerHTML = '';
                if (produto) {
                    const detalhesItem = document.createElement('p');
                    detalhesItem.textContent = `Código: ${codigo}, Descrição: ${produto.descricao}, Unidade de Medida: ${produto.unidadeDeMedida}, Vencimento: ${produto.vencimento}`;
                    produtoDetalhes.appendChild(detalhesItem);
                } else {
                    const erroItem = document.createElement('p');
                    erroItem.textContent = 'Produto não encontrado.';
                    produtoDetalhes.appendChild(erroItem);
                }
            });
    }

    // Listar produtos por código ao enviar o formulário
    const buscarForm = document.getElementById('buscar-form');
    buscarForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const codigo = document.getElementById('codigo').value;
        buscarProdutoPorCodigo(codigo);
    });


// Cadastrar produto
const produtoForm = document.getElementById('produto-form');
const feedbackElement = document.getElementById('feedback');

produtoForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const descricao = document.getElementById('descricao').value;
    const unidadeDeMedida = document.getElementById('unidadeDeMedida').value;
    const vencimento = document.getElementById('vencimento').value;

    console.log('Dados do produto a ser cadastrado:');
    console.log('Descrição:', descricao);
    console.log('Unidade de Medida:', unidadeDeMedida);
    console.log('Vencimento:', vencimento);

    fetch(`${baseUrl}/produtos`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ descricao, unidadeDeMedida, vencimento })
    })
    .then(response => {
        if (response.status === 201) {
            feedbackElement.textContent = 'Produto cadastrado com sucesso!';
            feedbackElement.classList.remove('error');
            feedbackElement.classList.add('success');
            feedbackElement.style.display = 'block';

            // Limpar os campos do formulário após o cadastro bem-sucedido
            document.getElementById('descricao').value = '';
            document.getElementById('unidadeDeMedida').value = '';
            document.getElementById('vencimento').value = '';

            // Atualizar a lista de produtos após o cadastro bem-sucedido
            listarProdutos();
        } else {
            return response.json().then(errorData => {
                console.error(`Erro na solicitação: ${response.status}`, errorData);
                feedbackElement.textContent = 'Erro ao cadastrar o produto.';
                feedbackElement.classList.remove('success');
                feedbackElement.classList.add('error');
                feedbackElement.style.display = 'block';
                throw new Error(`Erro na solicitação: ${response.status}`);
            });
        }
    })
    .catch(error => {
        console.error(error);
        // Lidar com erros na solicitação
    });
});

    // Atualizar produto
    const atualizarForm = document.getElementById('atualizar-form');
    atualizarForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const codigo = document.getElementById('atualizarCodigo').value;
        const descricao = document.getElementById('atualizarDescricao').value;
        const unidadeDeMedida = document.getElementById('atualizarUnidadeDeMedida').value;
        const vencimento = document.getElementById('atualizarVencimento').value;

        fetch(`${baseUrl}/produtos/${codigo}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ descricao, unidadeDeMedida, vencimento })
        })
        .then(response => {
            if (response.status === 200) {
                // Recarregar a lista de produtos após a atualização bem-sucedida
                window.location.reload();
            }
        });
    });

    // Excluir produto
    const excluirForm = document.getElementById('excluir-form');
    excluirForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const codigo = document.getElementById('excluirCodigo').value;

        fetch(`${baseUrl}/produtos/${codigo}`, {
            method: 'DELETE'
        })
        .then(response => {
            if (response.status === 200) {
                function showPopup(message) {
                    const popup = document.getElementById('popup');
                    const popupMessage = document.getElementById('popup-message');
                
                    popupMessage.textContent = message;
                    popup.style.display = 'block';
                
                    // Feche o pop-up automaticamente após 3 segundos (pode ajustar o tempo conforme necessário)
                    setTimeout(() => {
                        hidePopup();
                        window.location.reload()
                    }, 3000);
                }
                
                // Função para ocultar o pop-up
                function hidePopup() {
                    const popup = document.getElementById('popup');
                    popup.style.display = 'none';
                }
                
                // Exemplo de uso para exibir o pop-up ao excluir um item
                showPopup('Item excluído com sucesso.');
            }
            if(response.status === 404)
            {
                function showPopup(message) {
                    const popup = document.getElementById('popup');
                    const popupMessage = document.getElementById('popup-message');
                
                    popupMessage.textContent = message;
                    popup.style.display = 'block';
                
                    // Feche o pop-up automaticamente após 3 segundos (pode ajustar o tempo conforme necessário)
                    setTimeout(() => {
                        hidePopup();
                    }, 3000);
                }
                
                // Função para ocultar o pop-up
                function hidePopup() {
                    const popup = document.getElementById('popup');
                    popup.style.display = 'none';
                }
                
                // Exemplo de uso para exibir o pop-up ao excluir um item
                showPopup('Item não encontrado');
            }
        });
    });

 

});
