INSERT INTO Produto (Descricao, UnidadeDeMedida, Vencimento)
VALUES
    ('Yeezy', 39, DATEADD(MONTH, 12, GETDATE())),
    ('Nike Dunk', 41, DATEADD(MONTH, 13, GETDATE())),
    ('Air Max', 36, DATEADD(MONTH, 14, GETDATE())),
    ('Ultra Boost', 42, DATEADD(MONTH, 15, GETDATE())),
    ('UltraKick', 45, DATEADD(MONTH, 16, GETDATE())),
    ('Ki chute do Vampeta', 47, DATEADD(MONTH, 17, GETDATE())),
    ('Hadashuramaga', 47, DATEADD(MONTH, 17, GETDATE()))